This folder is for Add-on product images.

There are currently no add-on assets in the Intellicare image repository,
so this folder is empty and the "Add-ons" filter will show an empty state
in the app until items are added.

To add add-ons in the future:
1. Drop the image file(s) in this folder (images/addons/).
2. Add a matching row to products.csv with:
   - AssetType = Addon
   - Category  = Add-ons
   - Image     = addons/your-file-name.jpg
