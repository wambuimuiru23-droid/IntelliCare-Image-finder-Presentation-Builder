/* ===========================================================
   Intellicare Image Finder & Presentation Creator — presentation.js
   Builds a customer-facing .pptx catalogue from a set of
   selected items (the "catalogue cart"), grouped and chunked
   automatically:

     1. Group selected items by type (Product / Finish /
        Accessory / Hardware / Addon).
     2. Within Products, group by series (Category field).
     3. Chunk each group according to the chosen density
        (Compact = 6/slide, Standard = 4/slide, Detailed = 2/slide).
     4. Only sections that actually have selected items appear —
        no empty "Hardware" slide if nothing was added.

   This file has no dependency on the DOM by itself — buildDeck()
   takes a PptxGenJS constructor and plain data, so the same
   logic can run in the browser (with images pre-loaded as
   base64) or under Node for testing.
   =========================================================== */

(function (root, factory) {
  if (typeof module !== "undefined" && module.exports) {
    module.exports = factory();
  } else {
    root.IOFPresentation = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // ---------------------------------------------------------
  // THEME — "Revello" (layout/colors originally matched the reference
  // deck "Dorval Revello Presentation.dc.html" supplied 2026-09-16)
  //
  // FONT: Segoe UI throughout (changed 2026-09-17 from "Outfit"). Outfit
  // is a Google Font, not bundled with Windows/Office — on a machine that
  // doesn't have it installed (the overwhelming majority of corporate
  // Windows machines, including whatever an executive is likely to open
  // this on), PowerPoint silently substitutes a fallback font, so what
  // was actually being seen was never guaranteed to be the intended
  // design. Segoe UI is Microsoft's own system/Office typeface — it's
  // installed on every Windows machine by definition, so there is no
  // substitution risk, and it reads as standard, current corporate
  // software typography (Office, Teams, LinkedIn all use it) — the "make
  // it look official for executives" ask this changed in response to.
  // ---------------------------------------------------------
  const THEME = {
    cream: "F6F0E4",        // content slide background (Contents / item grids)
    navy: "161C28",         // full-bleed dark panel background (Cover / dividers / closing)
    veil: "0C111A",         // color used for the stacked-transparency photo veil
    ink: "1C2533",          // headline + strong body text on cream
    bodyGrey: "3A4048",     // paragraph text on cream
    metaGrey: "6B655A",     // product code / meta text on cream
    footerGrey: "7A7468",   // footer bar text on cream
    gold: "C8A96E",         // rule lines, "List" label, TOC numerals
    goldMuted: "A9853F",    // uppercase eyebrow labels on cream
    goldItalic: "E6C98C",   // italic subtitle text on dark backgrounds
    white: "FFFFFF",
    hairline: "DAD2BE",     // ~rgba(28,37,51,0.18) flattened onto the cream bg for pptx borders
    hairlineDark: "39404E", // hairline on navy backgrounds
    // NOTE: previously mixed Cormorant Garamond (serif, display headlines)
    // with Outfit (sans, labels/meta) — unified to Outfit only throughout
    // per 2026-09-17 feedback ("change the font to make it look
    // professional" / inconsistent typography across slides).
    sansFont: "Segoe UI",
  };

  const DENSITY = {
    Compact: 6,
    Standard: 4,
    Detailed: 3,
  };

  const SERIES_ORDER = ["100 Series", "200 Series", "300 Series", "400 Series", "500 Series", "600 Series"];

  // Collection/line names, pulled directly from real product names in the
  // data (confirmed against products.csv, not guessed — Josh himself
  // couldn't remember all of them on the call). Used only for what's
  // DISPLAYED in the deck; the underlying Category field ("100 Series"
  // etc.) is unchanged everywhere else, since finish AppliesTo tokens
  // (e.g. "Lumen:400 Series") and other matching logic depend on it.
  const SERIES_NAMES = {
    "100 Series": "Heritage",
    "200 Series": "Cube",
    "300 Series": "Studio",
    "400 Series": "Contour",
    "500 Series": "Resolve",
    "600 Series": "Foundation",
  };
  const seriesDisplayName = (key) => SERIES_NAMES[key] || key;

  // ---------------------------------------------------------
  // HELPERS
  // ---------------------------------------------------------
  function chunk(arr, size) {
    const out = [];
    for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
    return out;
  }

  function todayFormatted() {
    const d = new Date();
    return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  }

  /**
   * Groups cart items into an ordered list of sections, each already
   * chunked into slide-sized pages. Only non-empty, toggle-enabled
   * sections are included.
   *
   * @param {Array} cartItems - full CSV row objects (AssetType, Category, ...)
   * @param {Object} options - { density, includeFinishes, includeAccessories, includeHardware, includeAddons }
   * @returns {Array<{ key, label, items }>} one entry per slide-page
   */
  function buildGroups(cartItems, options) {
    const perSlide = DENSITY[options.density] || DENSITY.Standard;
    const sections = [];

    // ---- Products, grouped by series ----
    const products = cartItems.filter((i) => i.AssetType === "Product");
    const bySeries = {};
    products.forEach((p) => {
      const key = SERIES_ORDER.includes(p.Category) ? p.Category : "Other";
      (bySeries[key] = bySeries[key] || []).push(p);
    });
    const seriesKeys = [...SERIES_ORDER.filter((s) => bySeries[s]), ...(bySeries["Other"] ? ["Other"] : [])];
    seriesKeys.forEach((seriesKey) => {
      const pages = chunk(bySeries[seriesKey], perSlide);
      pages.forEach((pageItems, idx) => {
        sections.push({
          key: `series:${seriesKey}:${idx}`,
          kind: "products",
          seriesKey,
          label: seriesKey === "Other" ? "Your Selections" : seriesDisplayName(seriesKey),
          pageIndex: idx,
          pageCount: pages.length,
          items: pageItems,
        });
      });
    });

    // ---- Asset sections (Finishes / Accessories / Hardware / Add-ons) ----
    const assetDefs = [
      { type: "Finish", label: "Finishes", toggle: "includeFinishes" },
      { type: "Accessory", label: "Accessories", toggle: "includeAccessories" },
      { type: "Hardware", label: "Hardware", toggle: "includeHardware" },
      { type: "Addon", label: "Add-ons", toggle: "includeAddons" },
    ];

    assetDefs.forEach((def) => {
      if (options[def.toggle] === false) return;
      const items = cartItems.filter((i) => i.AssetType === def.type);
      if (items.length === 0) return;
      const pages = chunk(items, perSlide);
      pages.forEach((pageItems, idx) => {
        sections.push({
          key: `${def.type}:${idx}`,
          kind: "assets",
          label: def.label,
          pageIndex: idx,
          pageCount: pages.length,
          items: pageItems,
        });
      });
    });

    return sections;
  }

  /** Groups product items by series key ("100 Series".."600 Series", or "Other"). */
  function groupProductsBySeries(cartItems) {
    const bySeries = {};
    cartItems.filter((i) => i.AssetType === "Product").forEach((p) => {
      const key = SERIES_ORDER.includes(p.Category) ? p.Category : "Other";
      (bySeries[key] = bySeries[key] || []).push(p);
    });
    return bySeries;
  }

  /**
   * Builds the detailed Table of Contents entries directly from the cart
   * (not from the already-paginated `sections`), so a series' full list of
   * product types shows up regardless of how many slides it spans.
   * e.g. "300 Series" -> subtitle "Wardrobes, Bedsides, Dressers".
   */
  function buildTocData(cartItems, options) {
    const entries = [];

    const bySeries = groupProductsBySeries(cartItems);
    const seriesKeys = [...SERIES_ORDER.filter((s) => bySeries[s]), ...(bySeries["Other"] ? ["Other"] : [])];
    seriesKeys.forEach((seriesKey) => {
      const title = seriesKey === "Other" ? "Your Selections" : seriesDisplayName(seriesKey);
      entries.push({ title, subtitle: seriesCategories(bySeries[seriesKey]), count: bySeries[seriesKey].length });
    });

    const assetDefs = [
      { type: "Finish", label: "Finishes", toggle: "includeFinishes" },
      { type: "Accessory", label: "Accessories", toggle: "includeAccessories" },
      { type: "Hardware", label: "Hardware", toggle: "includeHardware" },
      { type: "Addon", label: "Add-ons", toggle: "includeAddons" },
    ];
    assetDefs.forEach((def) => {
      if (options[def.toggle] === false) return;
      const count = cartItems.filter((i) => i.AssetType === def.type).length;
      if (count > 0) {
        entries.push({ title: def.label, subtitle: "", count });
      }
    });

    return entries;
  }

  /** Distinct product-category labels for a series, in order of first appearance, e.g. "Wardrobes, Bedsides". */
  function seriesCategories(items) {
    const seen = new Set();
    const cats = [];
    items.forEach((i) => {
      const c = (i.ProductCategory || "").trim();
      if (c && !seen.has(c)) { seen.add(c); cats.push(pluralize(c)); }
    });
    // Bounded regardless of how many distinct categories a cart combines
    // (e.g. a large "Your Selections" bucket) — otherwise this string can
    // grow without limit and overflow whatever box it's shown in.
    const MAX_SHOWN = 4;
    if (cats.length > MAX_SHOWN) {
      return `${cats.slice(0, MAX_SHOWN).join(", ")} +${cats.length - MAX_SHOWN} more`;
    }
    return cats.join(", ");
  }

  function pluralize(word) {
    if (/(s|ing)$/i.test(word)) return word; // "-ing" nouns (Seating, etc.) are already mass nouns — don't add "s"
    return word + "s";
  }

  function pageSuffix(section) {
    return section.pageCount > 1 ? ` (${section.pageIndex + 1} of ${section.pageCount})` : "";
  }

  // ---------------------------------------------------------
  // SLIDE BUILDERS
  // ---------------------------------------------------------
  // Evergreen Intellicare brand statement — approved copy, used on the
  // cover's right panel. Not generated per-customer; this is fixed content.
  const BRAND_HEADLINE_PLAIN = "Furniture that ages with ";
  const BRAND_HEADLINE_EMPHASIS = "dignity.";
  const BRAND_PARAS = [
    "Premium, durable casegoods and seating engineered for Long Term Care, Skilled Nursing, and Assisted Living environments. Field-serviceable, endlessly customizable, and backed by a 25-year warranty.",
    "All designed and built-to-order in our Mississauga factories.",
  ];

  /** Thin gold rule — the reference design's signature underline accent. */
  function addRule(slide, x, y, w, color) {
    slide.addShape("rect", { x, y, w, h: 0.021, fill: { color: color || THEME.gold }, line: { type: "none" } });
  }

  /**
   * Footer bar used on every slide after the cover: a hairline top border,
   * "Customer · Deck Title" on the left, page number on the right —
   * matches the reference deck's "Dorval · Revello Collection ... 04" bar.
   */
  function addFooterBar(slide, opts, pageNum, dark) {
    // NOTE: charSpacing + transparency together on one text run clips text
    // in LibreOffice's renderer (confirmed via isolated test). Using a
    // pre-muted color instead of white+transparency avoids the combination.
    const color = dark ? "C9CDD4" : THEME.footerGrey;
    const lineColor = dark ? THEME.hairlineDark : THEME.hairline;
    const y = 5.2;
    slide.addShape("line", { x: 0.55, y, w: 8.9, h: 0, line: { color: lineColor, width: 0.75 } });
    const label = "Intellicare Furniture";
    slide.addText(label.toUpperCase(), {
      x: 0.55, y: y + 0.07, w: 6.6, h: 0.3,
      fontFace: THEME.sansFont, fontSize: 9, color, charSpacing: 1.2,
    });
    slide.addText(String(pageNum), {
      x: 8.35, y: y + 0.07, w: 1.1, h: 0.3, align: "right",
      fontFace: THEME.sansFont, fontSize: 9, color, charSpacing: 1.2,
    });
  }

  /**
   * Left-anchored dark veil over a full-bleed photo (cover, series
   * dividers). This is a real smooth gradient image (see
   * script.js#makeGradientDataUri) stretched over the target box —
   * a genuine per-pixel fade, not an approximation. Falls back to a flat
   * translucent rectangle only if the gradient image wasn't supplied
   * (defensive — buildDeck always generates one).
   */
  function addLeftVeil(slide, x, y, w, h, gradients, color) {
    if (gradients && gradients.leftVeil) {
      slide.addImage({ data: gradients.leftVeil, x, y, w, h });
    } else {
      slide.addShape("rect", { x, y, w: w * 0.65, h, fill: { color: color || THEME.veil, transparency: 30 }, line: { type: "none" } });
    }
  }

  function addCoverSlide(pres, opts, heroImage, logo, gradients) {
    const slide = pres.addSlide();
    slide.background = { color: THEME.cream };

    const leftW = 5.66; // ~1086/1920 of the reference deck's proportions
    const rightX = leftW;
    const rightW = 10 - rightX;

    // ---- Left: full-bleed lifestyle photo, filling the entire panel ----
    // "cover" sizing: fills the panel corner-to-corner, cropping whatever
    // overflows the aspect ratio — never distorts/stretches the image.
    // (Earlier used "contain" + a blurred backdrop to show the photo
    // fully uncropped; per 2026-09-17 feedback that's reverted in favor
    // of a full, edge-to-edge fill, matching how the divider/closing
    // slides already treat their photos.)
    slide.addShape("rect", { x: 0, y: 0, w: leftW, h: 5.625, fill: { color: THEME.navy }, line: { type: "none" } });
    if (heroImage && heroImage.data) {
      const nw = heroImage.w || leftW, nh = heroImage.h || 5.625;
      slide.addImage({ data: heroImage.data, x: 0, y: 0, w: nw, h: nh, sizing: { type: "cover", w: leftW, h: 5.625 } });
    }
    addLeftVeil(slide, 0, 0, leftW, 5.625, gradients);
    // Extra bottom-up fade so the "Prepared by" footer text stays legible —
    // same smooth-gradient approach, rotated to fade upward from the base.
    if (gradients && gradients.bottomFade) {
      slide.addImage({ data: gradients.bottomFade, x: 0, y: 3.625, w: leftW, h: 2.0 });
    }

    // NOTE: the cover only carries the logo on the right (cream) panel —
    // no duplicate logo on the left photo panel (per 2026-09-16 feedback).

    const customerName = opts.customer || "Valued Customer";
    // Long customer names wrap to more lines at a fixed 44pt — shrink the
    // font and reserve proportionally more height for longer names so
    // "PRESENTED TO" / the name / the title can never collide, regardless
    // of name length (this used to be fixed-height and would overlap
    // badly on anything longer than ~16 characters).
    //
    // IMPORTANT: character count alone doesn't predict whether a name
    // wraps — "Valued Customer" (the default placeholder, 15 characters)
    // still wraps to 2 lines at 44pt even though it's well under the old
    // 16-char threshold, because word-wrap breaks at the space regardless
    // of how much room a single word of the same total length would have
    // had. So nameH is no longer "how much room does this text need" —
    // it always reserves 2 full lines at whatever font size was picked,
    // confirmed against real rendered output, so it's safe whether or
    // not the name actually wraps.
    // NOTE: hand-tuned nameH values have been wrong twice now at
    // increasing name lengths (a 15-char two-word name, then a 51-char
    // one) — actual PowerPoint/LibreOffice line-height for this font
    // apparently runs higher than the ~1.2x commonly assumed. Switched to
    // a formula with a deliberately generous 1.5x line-height multiplier
    // and one more tier for very long names, so it's safe with a real
    // margin rather than being re-tuned to the exact previous failure.
    const nameLen = customerName.length;
    let nameFontSize, maxLines;
    if (nameLen > 55) { nameFontSize = 18; maxLines = 4; }
    else if (nameLen > 40) { nameFontSize = 22; maxLines = 4; }
    else if (nameLen > 24) { nameFontSize = 28; maxLines = 3; }
    else { nameFontSize = 36; maxLines = 2; }
    const nameH = (nameFontSize * 1.5 / 72) * maxLines + 0.1;

    let cy = 0.78;
    slide.addText("PRESENTED TO", {
      x: 0.53, y: cy, w: leftW - 1.0, h: 0.35,
      fontFace: THEME.sansFont, fontSize: 13, bold: true, color: THEME.gold, charSpacing: 2.6,
    });
    cy += 0.37;
    slide.addText(customerName, {
      x: 0.53, y: cy, w: leftW - 0.9, h: nameH,
      fontFace: THEME.sansFont, fontSize: nameFontSize, color: THEME.white, valign: "top",
    });
    cy += nameH + 0.03;
    const titleText = opts.title || "Product Presentation";
    let titleFontSize, titleMaxLines;
    if (titleText.length > 60) { titleFontSize = 14; titleMaxLines = 3; }
    else if (titleText.length > 35) { titleFontSize = 16; titleMaxLines = 3; }
    else { titleFontSize = 18; titleMaxLines = 2; }
    const titleH = (titleFontSize * 1.5 / 72) * titleMaxLines + 0.08;
    slide.addText(titleText, {
      x: 0.53, y: cy, w: leftW - 0.9, h: titleH,
      fontFace: THEME.sansFont, fontSize: titleFontSize, bold: true, color: THEME.goldItalic, valign: "top",
    });
    cy += titleH;
    addRule(slide, 0.53, cy + 0.08, 0.72);
    slide.addText(`Prepared by ${opts.salesRep || "Your Intellicare Representative"}   ·   ${todayFormatted()}`, {
      x: 0.53, y: 4.92, w: leftW - 0.9, h: 0.35,
      fontFace: THEME.sansFont, fontSize: 12, color: "E4E6EA", charSpacing: 0.6,
    });

    // ---- Right: cream panel, brand headline + evergreen statement ----
    const textX = rightX + 0.42, textW = rightW - 0.42 - 0.3;
    let ty = 0.55;
    if (logo && logo.color && logo.color.data) {
      const lh = 0.42;
      const lw = lh * ((logo.color.w || 6) / (logo.color.h || 5));
      slide.addImage({ data: logo.color.data, x: textX, y: ty, w: lw, h: lh });
      ty += 0.72;
    }
    slide.addText(
      [
        { text: BRAND_HEADLINE_PLAIN, options: { color: THEME.ink } },
        { text: BRAND_HEADLINE_EMPHASIS, options: { color: THEME.goldMuted, italic: true } },
      ],
      { x: textX, y: ty, w: textW, h: 0.95, fontFace: THEME.sansFont, fontSize: 22, bold: true, valign: "top", lineSpacingMultiple: 1.05 }
    );
    ty += 1.08;
    addRule(slide, textX, ty, 0.6);
    ty += 0.22;
    slide.addText(BRAND_PARAS.join("\n\n"), {
      x: textX, y: ty, w: textW, h: 5.02 - ty - 0.08,
      fontFace: THEME.sansFont, fontSize: 11.5, color: THEME.bodyGrey, lineSpacingMultiple: 1.3, valign: "top",
    });
    slide.addShape("line", { x: textX, y: 5.02, w: textW, h: 0, line: { color: THEME.hairline, width: 0.75 } });
    slide.addText("MISSISSAUGA, ONTARIO", {
      x: textX, y: 5.08, w: textW, h: 0.3,
      fontFace: THEME.sansFont, fontSize: 9, color: THEME.footerGrey, charSpacing: 1.2,
    });
  }

  function addTocSlide(pres, entries, heroImage, logo, opts, pageNum) {
    const slide = pres.addSlide();
    slide.background = { color: THEME.cream };

    slide.addText("IN THIS PRESENTATION", {
      x: 0.55, y: 0.45, w: 6, h: 0.32,
      fontFace: THEME.sansFont, fontSize: 12, bold: true, color: THEME.goldMuted, charSpacing: 2.2,
    });
    slide.addText("Table of Contents", {
      x: 0.55, y: 0.78, w: 6, h: 0.7,
      fontFace: THEME.sansFont, fontSize: 32, bold: true, color: THEME.ink,
    });
    addRule(slide, 0.55, 1.5, 0.72);
    addCornerLogo(slide, logo);

    const rowsTop = 1.82, rowsBottom = 5.05; // small extra breathing room before the footer at 5.2
    const available = rowsBottom - rowsTop;
    const n = Math.max(entries.length, 1);
    const baselineRowH = Math.min(0.72, available / n);
    const numFontSize = Math.min(26, baselineRowH * 44);
    const titleFontSize = Math.min(16, baselineRowH * 24);
    let subFontSize = Math.min(10.5, baselineRowH * 15);

    // Conservative chars/line estimate for the subtitle's actual width —
    // erring toward assuming MORE lines than it needs, matching the
    // safety-margin approach used elsewhere after getting this wrong at
    // increasing lengths more than once already.
    const computeRowHeights = (subFS) => entries.map((entry) => {
      const subLines = entry.subtitle ? Math.max(1, Math.ceil(entry.subtitle.length / 58)) : 0;
      const neededH = subLines > 0
        ? baselineRowH * 0.42 + subLines * (subFS * 1.5 / 72) + 0.12
        : baselineRowH;
      return Math.max(baselineRowH, neededH);
    });

    let rowHeights = computeRowHeights(subFontSize);
    let totalH = rowHeights.reduce((a, b) => a + b, 0);
    // If the rows as computed don't fit in the available space (e.g. a
    // "Your Selections" row combining many categories), shrink the
    // subtitle font — which shrinks its needed height too — rather than
    // letting any row overflow into the footer. If it's still too tall
    // even at a legible font floor (an extreme case), scale the row
    // heights directly as a last resort so nothing ever overflows.
    if (totalH > available) {
      subFontSize = Math.max(7, subFontSize * (available / totalH));
      rowHeights = computeRowHeights(subFontSize);
      totalH = rowHeights.reduce((a, b) => a + b, 0);
      if (totalH > available) {
        const scale2 = available / totalH;
        rowHeights = rowHeights.map((h) => h * scale2);
      }
    }

    let y = rowsTop;
    entries.forEach((entry, idx) => {
      const rowH = rowHeights[idx];

      slide.addShape("line", { x: 0.55, y, w: 8.9, h: 0, line: { color: THEME.hairline, width: 0.75 } });
      const numY = y + Math.min(rowH, baselineRowH) * 0.5 - 0.24;
      slide.addText(String(idx + 1).padStart(2, "0"), {
        x: 0.55, y: numY, w: 0.85, h: 0.48,
        fontFace: THEME.sansFont, fontSize: numFontSize, bold: true, color: THEME.goldMuted, valign: "middle",
      });
      const textY = y + baselineRowH * 0.18;
      slide.addText(entry.title, {
        x: 1.5, y: textY, w: 5.5, h: baselineRowH * 0.5,
        fontFace: THEME.sansFont, fontSize: titleFontSize, bold: true, color: THEME.ink, valign: "top",
      });
      if (entry.subtitle) {
        slide.addText(entry.subtitle, {
          x: 1.5, y: textY + baselineRowH * 0.42, w: 5.5, h: rowH - baselineRowH * 0.42,
          fontFace: THEME.sansFont, fontSize: subFontSize, color: THEME.metaGrey, valign: "top", wrap: true,
        });
      }
      if (entry.count != null) {
        slide.addText(`${entry.count} item${entry.count === 1 ? "" : "s"}`, {
          x: 7.1, y: y + Math.min(rowH, baselineRowH) / 2 - 0.15, w: 1.35, h: 0.3, align: "right",
          fontFace: THEME.sansFont, fontSize: 9.5, color: THEME.footerGrey, charSpacing: 1,
        });
      }
      y += rowH;
    });
    slide.addShape("line", { x: 0.55, y, w: 8.9, h: 0, line: { color: THEME.hairline, width: 0.75 } });

    addFooterBar(slide, opts, pageNum, false);
  }

  /** Small color-logo mark, top-right corner — used on light-background content slides. */
  function addCornerLogo(slide, logo) {
    if (!logo || !logo.color || !logo.color.data) return;
    const lh = 0.4;
    const lw = lh * ((logo.color.w || 6) / (logo.color.h || 5));
    slide.addImage({ data: logo.color.data, x: 9.5 - lw, y: 0.42, w: lw, h: lh });
  }

  /** Small white-logo mark — used on dark full-bleed slides (top-left, matching the reference deck). */
  function addCornerLogoWhite(slide, logo) {
    if (!logo || !logo.white || !logo.white.data) return;
    const lh = 0.4;
    const lw = lh * ((logo.white.w || 6) / (logo.white.h || 5));
    slide.addImage({ data: logo.white.data, x: 0.53, y: 0.42, w: lw, h: lh, transparency: 6 });
  }

  function addSeriesDividerSlide(pres, seriesLabel, subtitle, heroImage, logo, opts, pageNum, sectionOrdinal, gradients) {
    const slide = pres.addSlide();
    slide.background = { color: THEME.navy };

    if (heroImage && heroImage.data) {
      const nw = heroImage.w || 10, nh = heroImage.h || 5.625;
      slide.addImage({ data: heroImage.data, x: 0, y: 0, w: nw, h: nh, sizing: { type: "cover", w: 10, h: 5.625 } });
    }
    addLeftVeil(slide, 0, 0, 10, 5.625, gradients);

    addCornerLogoWhite(slide, logo);

    const textX = 0.53, textW = 4.6;
    slide.addText(`SECTION ${sectionOrdinal}`, {
      x: textX, y: 1.55, w: textW, h: 0.32,
      fontFace: THEME.sansFont, fontSize: 13, bold: true, color: THEME.gold, charSpacing: 2.6,
    });
    slide.addText(seriesLabel, {
      x: textX, y: 1.92, w: textW, h: 1.0,
      fontFace: THEME.sansFont, fontSize: 40, color: THEME.white,
    });
    let ruleY = 3.35;
    if (subtitle) {
      // Conservative chars/line estimate for 16pt bold sans in this
      // column width, deliberately erring toward assuming MORE lines
      // than it needs (safer to over-reserve than under-reserve) — the
      // previous estimate (30 chars/line, stale from when this text was
      // 18pt italic serif) undercounted lines for a long category list
      // and the rule ended up overlapping the wrapped text.
      const subtitleLines = Math.max(1, Math.ceil(subtitle.length / 26));
      const subtitleH = subtitleLines * 0.36 + 0.1;
      slide.addText(subtitle, {
        x: textX, y: 2.75, w: textW, h: subtitleH,
        fontFace: THEME.sansFont, fontSize: 16, bold: true, color: THEME.goldItalic, valign: "top",
      });
      ruleY = 2.75 + subtitleH + 0.1;
    }
    addRule(slide, textX, ruleY, 0.72);

    addFooterBar(slide, opts, pageNum, true);
  }

  /**
   * Truncates text to a character budget so it can never overflow its
   * reserved box, regardless of how pptxgenjs/PowerPoint actually wraps it.
   * This is a deliberately conservative heuristic (not real text metrics) —
   * the goal is "never overlaps," not "uses every last pixel."
   */
  function fitText(str, maxChars) {
    if (!str) return "";
    if (str.length <= maxChars) return str;
    return str.slice(0, Math.max(0, maxChars - 1)).trim() + "…";
  }

  /**
   * Computes the horizontal position/width for each block in a 1, 2, or
   * 3-product catalogue row. Image size is intentionally constant across
   * all three cases — only the surrounding whitespace changes.
   */
  function catalogueLayout(rawCount) {
    const count = Math.min(Math.max(rawCount, 1), 3); // defensive clamp — this layout only ever handles 1-3
    const slideX0 = 0.5, slideX1 = 9.5; // usable width
    if (count === 1) {
      const blockW = 3.3;
      return { blockW, positions: [(slideX0 + slideX1) / 2 - blockW / 2], dividers: [] };
    }
    if (count === 2) {
      const blockW = 3.6;
      const x0 = slideX0, x1 = slideX1 - blockW;
      return { blockW, positions: [x0, x1], dividers: [(x0 + blockW + x1) / 2] };
    }
    // count === 3
    const gap = 0.35;
    const blockW = (slideX1 - slideX0 - gap * 2) / 3;
    const x0 = slideX0, x1 = x0 + blockW + gap, x2 = x1 + blockW + gap;
    return {
      blockW,
      positions: [x0, x1, x2],
      dividers: [x0 + blockW + gap / 2, x1 + blockW + gap / 2],
    };
  }

  function addCatalogueBlock(slide, item, opts, x, blockW, top) {
    // imgH shrinks to compensate when the header (see addGridHeader) needed
    // more room for a long headline — keeps the price row landing at the
    // same safe bottom position regardless of how tall the header got,
    // rather than letting a tall header push the whole card off the slide.
    const imgH = Math.max(0.7, 3.184 - top);

    // White inset image "mat" with a hairline border, matching the
    // reference deck's product photo treatment.
    slide.addShape("rect", { x, y: top, w: blockW, h: imgH, fill: { color: THEME.white }, line: { color: THEME.hairline, width: 0.75 } });
    const pad = 0.12;
    if (item._imageData) {
      const availW = blockW - pad * 2, availH = imgH - pad * 2;
      const ratio = (item._imageW || 1) / (item._imageH || 1);
      let dw = availW, dh = dw / ratio;
      if (dh > availH) { dh = availH; dw = dh * ratio; }
      if (dw > availW) { dw = availW; dh = dw / ratio; } // re-clamp: the box is rectangular, not square, so a height fix can reintroduce a width overflow
      slide.addImage({
        data: item._imageData,
        x: x + (blockW - dw) / 2, y: top + (imgH - dh) / 2, w: dw, h: dh,
      });
    } else {
      slide.addText("No image", { x, y: top, w: blockW, h: imgH, align: "center", valign: "middle", fontFace: THEME.sansFont, fontSize: 9, color: THEME.metaGrey });
    }

    // Reserved zones below the image, stacked with a running cursor built
    // from each box's own height + a small gap — every block uses the same
    // sequence, so names/codes/descriptions/prices line up across all
    // blocks on the slide regardless of how much text each one has, and
    // can never overlap each other, because each y is derived from the
    // actual height reserved above it rather than an independently-guessed
    // constant.
    //
    // IMPORTANT: nameBudget (~41 chars at the narrowest 3-up column width)
    // reliably wraps to 3 lines at 15pt, not 2 — a product name doesn't
    // need to be anywhere near the character limit to do this (even a
    // plain "Lumen Heritage 1 Door / 2 Drawer Wardrobe" wraps to 3 lines
    // here). nameH must reserve for 3 lines, confirmed against real
    // rendered output, not estimated from the character count alone.
    const textX = x + 0.03;
    const textW = blockW - 0.06;
    const nameBudget = Math.round(blockW * 15);
    const descBudget = Math.round(blockW * 20);   // ~2 lines at this width/font

    const nameH = 0.8, codeH = 0.18, descH = 0.34;
    const gap = 0.04;

    let cursor = top + imgH + 0.14;
    slide.addText(fitText(item.ProductName || "", nameBudget), {
      x: textX, y: cursor, w: textW, h: nameH,
      fontFace: THEME.sansFont, fontSize: 15, bold: true, color: THEME.ink,
      valign: "top", wrap: true,
    });
    cursor += nameH + gap * 0.4;

    if (item.ProductCode) {
      slide.addText(item.ProductCode, {
        x: textX, y: cursor, w: textW, h: codeH,
        fontFace: THEME.sansFont, fontSize: 8.5, color: THEME.metaGrey, charSpacing: 0.8, valign: "top",
      });
    }
    cursor += codeH + gap;

    if (item.Description) {
      slide.addText(fitText(item.Description, descBudget), {
        x: textX, y: cursor, w: textW, h: descH,
        fontFace: THEME.sansFont, fontSize: 9, color: THEME.bodyGrey, valign: "top", wrap: true, lineSpacingMultiple: 1.2,
      });
    }
    cursor += descH + gap;

    if (opts.includePrices && item.Price) {
      const ruleY = cursor;
      const priceText = /confirm|request.*quote/i.test(item.Price) ? "Request a quote" : item.Price;
      slide.addText(
        [
          { text: "LIST  ", options: { fontFace: THEME.sansFont, fontSize: 9, bold: true, color: THEME.goldMuted, charSpacing: 1.4 } },
          { text: priceText, options: { fontFace: THEME.sansFont, fontSize: 15, bold: true, color: THEME.ink } },
        ],
        { x: textX, y: ruleY + 0.07, w: textW, h: 0.22, valign: "top" }
      );
    }
  }

  /**
   * Shared header for every cream-background content slide: uppercase
   * tracked eyebrow, serif headline, logo top-right, hairline rule below —
   * matches the reference deck's item-grid slide header exactly.
   */
  /**
   * Returns the y-position immediately below the header's divider rule,
   * so callers can position their own content dynamically instead of
   * assuming a fixed header height — a fixed 2-line assumption already
   * failed once (a "Dining Room Seating, Resident Room Seating – Sleep
   * Chairs" combination wraps to 2 lines) and failed again at 3 lines
   * with a longer combination, so this no longer guesses a line count at
   * a fixed font size — it shrinks the font for long headlines and
   * estimates lines conservatively (erring toward too many, not too few).
   */
  function addGridHeader(slide, eyebrow, headline, logo) {
    slide.addText(eyebrow.toUpperCase(), {
      x: 0.55, y: 0.38, w: 7.6, h: 0.3,
      fontFace: THEME.sansFont, fontSize: 11, bold: true, color: THEME.goldMuted, charSpacing: 2,
    });
    let fontSize = 24, charsPerLine = 32;
    if (headline.length > 90) { fontSize = 18; charsPerLine = 42; }
    else if (headline.length > 55) { fontSize = 20; charsPerLine = 37; }
    const lines = Math.max(1, Math.ceil(headline.length / charsPerLine));
    const headlineH = lines * (fontSize * 1.5 / 72) + 0.1;
    slide.addText(headline, {
      x: 0.55, y: 0.68, w: 7.6, h: headlineH,
      fontFace: THEME.sansFont, fontSize, bold: true, color: THEME.ink, valign: "top",
    });
    addCornerLogo(slide, logo);
    const ruleY = 0.68 + headlineH + 0.08;
    slide.addShape("line", { x: 0.55, y: ruleY, w: 8.9, h: 0, line: { color: THEME.hairline, width: 0.75 } });
    return ruleY;
  }

  function addProductCompactGridSlide(pres, section, opts, pageNum, sectionOrdinal) {
    const slide = pres.addSlide();
    slide.background = { color: THEME.cream };
    const headline = seriesCategories(section.items) || section.label;
    const headerBottom = addGridHeader(slide, `Section ${sectionOrdinal}  ·  ${section.label}${pageSuffix(section)}`, headline, opts.logo);

    const perSlide = DENSITY[opts.density] || DENSITY.Standard;
    const cols = perSlide === 6 ? 3 : 2;
    const rows = perSlide === 6 ? 2 : 2;

    const gridX = 0.55, gridY = headerBottom + 0.23, gridW = 8.9, gridH = 5.1 - gridY;
    const cellW = gridW / cols, cellH = gridH / rows;

    section.items.forEach((item, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const cx = gridX + col * cellW;
      const cy = gridY + row * cellH;
      const pad = 0.16;

      const imgSize = Math.min(cellW, cellH) - 1.1;
      const imgX = cx + (cellW - imgSize) / 2;
      const imgY = cy + pad;

      slide.addShape("rect", { x: imgX, y: imgY, w: imgSize, h: imgSize, fill: { color: THEME.white }, line: { color: THEME.hairline, width: 0.75 } });
      if (item._imageData) {
        const ratio = (item._imageW || 1) / (item._imageH || 1);
        const inset = imgSize - 0.16;
        let dw = inset, dh = dw / ratio;
        if (dh > inset) { dh = inset; dw = dh * ratio; }
        slide.addImage({ data: item._imageData, x: imgX + (imgSize - dw) / 2, y: imgY + (imgSize - dh) / 2, w: dw, h: dh });
      } else {
        slide.addText("No image", { x: imgX, y: imgY, w: imgSize, h: imgSize, align: "center", valign: "middle", fontFace: THEME.sansFont, fontSize: 9, color: THEME.metaGrey });
      }

      // Fixed reserved zones below the image, same on every card — a
      // wrapped 2-line name can never collide with the code/price below it.
      const textX = cx + pad, textW = cellW - pad * 2;
      const nameBudget = Math.round(cellW * 15);
      let y = imgY + imgSize + 0.1;
      slide.addText(fitText(item.ProductName || "", nameBudget), {
        x: textX, y, w: textW, h: 0.36,
        fontFace: THEME.sansFont, fontSize: 12, bold: true, color: THEME.ink, align: "center", valign: "top", wrap: true,
      });

      y = imgY + imgSize + 0.1 + 0.34;
      if (item.ProductCode) {
        slide.addText(item.ProductCode, {
          x: textX, y, w: textW, h: 0.2,
          fontFace: THEME.sansFont, fontSize: 7.5, color: THEME.metaGrey, align: "center", valign: "top",
        });
      }

      y = imgY + imgSize + 0.1 + 0.34 + 0.2;
      if (opts.includePrices && item.Price) {
        const priceText = /confirm|request.*quote/i.test(item.Price) ? "Request a quote" : item.Price;
        slide.addText(priceText, {
          x: textX, y, w: textW, h: 0.24,
          fontFace: THEME.sansFont, fontSize: 12, bold: true, color: THEME.goldMuted, align: "center", valign: "top",
        });
      }
    });

    addFooterBar(slide, opts, pageNum, false);
  }

  function addProductGridSlide(pres, section, opts, pageNum, sectionOrdinal) {
    // "Detailed" (up to 3/slide, full description+price) uses the dynamic
    // 1/2/3-up catalogue layout. Compact/Standard (6 or 4/slide) use the
    // simpler card grid — catalogueLayout() only has positions for up to
    // 3 items, so routing 4-6 items through it was the cause of items
    // overlapping at an undefined position.
    if ((DENSITY[opts.density] || DENSITY.Standard) === DENSITY.Detailed) {
      const slide = pres.addSlide();
      slide.background = { color: THEME.cream };
      const headline = seriesCategories(section.items) || section.label;
      const headerBottom = addGridHeader(slide, `Section ${sectionOrdinal}  ·  ${section.label}${pageSuffix(section)}`, headline, opts.logo);
      const top = headerBottom + 0.13;

      const { blockW, positions, dividers } = catalogueLayout(section.items.length);

      dividers.forEach((dx) => {
        slide.addShape("line", {
          x: dx, y: top, w: 0, h: 5.03 - top,
          line: { color: THEME.hairline, width: 0.75 },
        });
      });

      section.items.forEach((item, idx) => {
        addCatalogueBlock(slide, item, opts, positions[idx], blockW, top);
      });

      addFooterBar(slide, opts, pageNum, false);
      return;
    }

    addProductCompactGridSlide(pres, section, opts, pageNum, sectionOrdinal);
  }

  function addAssetGridSlide(pres, section, opts, pageNum, sectionOrdinal) {
    const slide = pres.addSlide();
    slide.background = { color: THEME.cream };
    const headerBottom = addGridHeader(slide, `Section ${sectionOrdinal}  ·  ${section.label}${pageSuffix(section)}`, section.label, opts.logo);

    // cols/rows sized from the actual item count on this slide (never more
    // than 3, since every section is chunked at DENSITY[options.density]
    // per slide) rather than a hardcoded branch on old density tiers —
    // that mismatch used to leave a 3rd item with no row to render into,
    // so it fell off the bottom of the slide entirely.
    const cols = Math.min(3, Math.max(1, section.items.length));
    const rows = Math.ceil(section.items.length / cols);

    const gridX = 0.55, gridY = headerBottom + 0.23, gridW = 8.9, gridH = 5.1 - gridY;
    const cellW = gridW / cols, cellH = gridH / rows;

    section.items.forEach((item, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const cx = gridX + col * cellW;
      const cy = gridY + row * cellH;
      const pad = 0.2;

      const imgSize = Math.min(cellW, cellH) - 1.0;
      const imgX = cx + (cellW - imgSize) / 2;
      const imgY = cy + pad;

      slide.addShape("rect", { x: imgX, y: imgY, w: imgSize, h: imgSize, fill: { color: THEME.white }, line: { color: THEME.hairline, width: 0.75 } });
      if (item._imageData) {
        const nw = item._imageW || imgSize, nh = item._imageH || imgSize;
        slide.addImage({ data: item._imageData, x: imgX, y: imgY, w: nw, h: nh, sizing: { type: "cover", w: imgSize, h: imgSize } });
      }

      slide.addText(item.ProductName || "", {
        x: cx + pad * 0.5, y: imgY + imgSize + 0.08, w: cellW - pad, h: 0.4,
        fontFace: THEME.sansFont, fontSize: 10, color: THEME.ink, align: "center",
      });
    });

    addFooterBar(slide, opts, pageNum, false);
  }

  function addClosingSlide(pres, hero, logo, opts, pageNum, gradients) {
    const slide = pres.addSlide();
    slide.background = { color: THEME.navy };

    const bandH = 2.6;
    if (hero && hero.data) {
      const nw = hero.w || 10, nh = hero.h || bandH;
      slide.addImage({ data: hero.data, x: 0, y: 0, w: nw, h: nh, sizing: { type: "cover", w: 10, h: bandH } });
    }
    // Fade the photo band into the navy background below it — a real
    // smooth gradient image rather than stacked flat-opacity bands.
    if (gradients && gradients.bottomFade) {
      slide.addImage({ data: gradients.bottomFade, x: 0, y: bandH - 1.1, w: 10, h: 1.1 });
    }

    addCornerLogoWhite(slide, logo);

    const textX = 0.53, textY0 = bandH + 0.22;
    slide.addText("NEXT STEPS", {
      x: textX, y: textY0, w: 8.9, h: 0.28,
      fontFace: THEME.sansFont, fontSize: 12, bold: true, color: THEME.gold, charSpacing: 2.4,
    });
    slide.addText("Thank you.", {
      x: textX, y: textY0 + 0.3, w: 8.9, h: 0.6,
      fontFace: THEME.sansFont, bold: true, fontSize: 30, color: THEME.white,
    });
    slide.addText("Questions? Your Intellicare representative is happy to help.", {
      x: textX, y: textY0 + 0.9, w: 8.9, h: 0.38,
      fontFace: THEME.sansFont, fontSize: 13, color: THEME.goldItalic,
    });

    const cols = [
      { label: "PREPARED BY", value: opts.salesRep || "Your Intellicare Representative" },
      { label: "CONTACT", value: "info@intellicarefurniture.com\n1.800.764.2392" },
      { label: "MANUFACTURED IN", value: "1710 Bonhill Road\nMississauga, ON L5T 1C8" },
    ];
    const colY = textY0 + 1.32; // headline block above ends ~textY0+1.28; leaves a hairline's worth of gap
    slide.addShape("line", { x: textX, y: colY, w: 8.9, h: 0, line: { color: THEME.hairlineDark, width: 0.75 } });
    const colW = 8.9 / 3;
    cols.forEach((c, i) => {
      const cx = textX + i * colW;
      slide.addText(c.label, {
        x: cx, y: colY + 0.14, w: colW - 0.1, h: 0.3,
        // NOTE: charSpacing + transparency together on one text run clips
        // text in LibreOffice's renderer (confirmed via isolated test —
        // neither property alone triggers it). Using a pre-muted color
        // instead of white+transparency avoids the combination entirely.
        fontFace: THEME.sansFont, fontSize: 9.5, bold: true, color: "9CA3AF", charSpacing: 1.0,
      });
      slide.addText(c.value, {
        x: cx, y: colY + 0.42, w: colW - 0.1, h: 0.5,
        fontFace: THEME.sansFont, fontSize: 11, color: THEME.white, lineSpacingMultiple: 1.3,
      });
    });

    addFooterBar(slide, opts, pageNum, true);
  }


  /**
   * Assemble the full deck.
   * @param {Function} PptxGenJSCtor - the PptxGenJS constructor (window.PptxGenJS or require('pptxgenjs'))
   * @param {Array} cartItems - selected item rows, each optionally carrying `_imageData` (base64 data URI)
   * @param {Object} options - { customer, title, salesRep, density, includePrices, includeFinishes, includeAccessories, includeHardware, includeAddons }
   * @param {Object} hero - { pool: Array<{data,w,h}>, closing: {data,w,h}|null } — `pool` is cycled through for the
   *   cover background, the contents photo, and each series divider so the deck doesn't reuse one photo everywhere.
   * @param {Object} logo - { color: {data,w,h}|null, white: {data,w,h}|null } — Intellicare logo, color for
   *   light-background slides, white (silhouette) variant for dark-background slides.
   * @returns {PptxGenJS} ready to .writeFile() / .write()
   */
  function buildDeck(PptxGenJSCtor, cartItems, options, hero, logo, gradients) {
    const pres = new PptxGenJSCtor();
    pres.layout = "LAYOUT_16x9"; // 10in x 5.625in, matches existing Intellicare customer decks

    const pool = (hero && hero.pool && hero.pool.length) ? hero.pool : [];
    let heroCursor = 0;
    const nextHero = () => {
      if (pool.length === 0) return null;
      const img = pool[heroCursor % pool.length];
      heroCursor++;
      return img;
    };

    const opts = Object.assign({ logo }, options);

    const sections = buildGroups(cartItems, opts);
    const tocData = buildTocData(cartItems, opts);
    const bySeries = groupProductsBySeries(cartItems);

    // Running page number (shown bottom-right on every slide, footer-bar
    // style, matching the reference deck's "04", "08" etc.) and a running
    // "Section N" ordinal (only advances at each new divider, matching the
    // reference's "Section one / two / three").
    let pageNum = 1;
    let sectionOrdinal = 0;

    addCoverSlide(pres, opts, nextHero(), logo, gradients);
    pageNum++;
    if (tocData.length > 0) {
      addTocSlide(pres, tocData, nextHero(), logo, opts, pageNum);
      pageNum++;
    }

    let lastSeriesLabel = null;
    sections.forEach((section) => {
      if (section.kind === "products") {
        if (section.pageIndex === 0 && section.label !== lastSeriesLabel) {
          sectionOrdinal++;
          addSeriesDividerSlide(pres, section.label, seriesCategories(bySeries[section.seriesKey] || []), nextHero(), logo, opts, pageNum, sectionOrdinal, gradients);
          pageNum++;
          lastSeriesLabel = section.label;
        }
        addProductGridSlide(pres, section, opts, pageNum, sectionOrdinal);
        pageNum++;
      } else {
        sectionOrdinal++;
        addAssetGridSlide(pres, section, opts, pageNum, sectionOrdinal);
        pageNum++;
      }
    });

    addClosingSlide(pres, hero && hero.closing, logo, opts, pageNum, gradients);

    return pres;
  }

  return {
    THEME,
    DENSITY,
    SERIES_ORDER,
    chunk,
    buildGroups,
    buildTocData,
    buildDeck,
  };
});
