/* ===========================================================
   Intellicare Image Finder & Presentation Creator — script.js
   Vanilla JS. No frameworks, no build step.

   DATA LOADING STRATEGY
   ----------------------
   Browsers block fetch() of local files when a page is opened
   directly as a file:// URL (no local server). To guarantee this
   app "just works" when someone double-clicks index.html, we:
     1. Try fetch('products.csv') first. If the app is served over
        http(s) (e.g. a local web server, intranet, etc.) this picks
        up live edits to products.csv immediately — this is the
        "dynamic" path.
     2. If that fetch fails (typical file:// case), we fall back to
        the copy of the CSV embedded in data.js at build time.

   To publish updates without a server: edit products.csv, then
   regenerate data.js from it (see README.md) so the fallback stays
   in sync.
   =========================================================== */

(() => {
  "use strict";

  // ---------- State ----------
  let allItems = [];          // every row from the CSV (products + finishes + accessories + addons)
  let filteredItems = [];     // after search + category filter
  let activeCategory = "All";
  let searchTerm = "";
  const selected = new Map(); // key: image path -> {path, name}

  const cart = new Map();     // key: cart key -> full item row (the "catalogue cart" for presentations)

  // Series order used for filter buttons (only shown if present in data)
  const SERIES_ORDER = ["100 Series", "200 Series", "300 Series", "400 Series", "500 Series", "600 Series"];

  // Extra single-select tabs appended after the series tabs, for browsing
  // Accessories/Finishes/Hardware directly as their own list (separate
  // from a product's own View panel, which still shows the item-specific
  // subset regardless of these tabs — see openModal/finishesForItem).
  const ASSET_TABS = [
    { key: "asset:Accessory", label: "Accessories", assetType: "Accessory" },
    { key: "asset:Finish", label: "Finishes", assetType: "Finish" },
    { key: "asset:Hardware", label: "Hardware", assetType: "Hardware" },
  ];

  // Rolls the data's granular ProductCategory values up into the broader
  // "room" categories used on the live site (confirmed against real counts
  // 2026-09-16: 9 of 10 buckets matched exactly, "Beds & Boards" was 23 vs
  // 24 — close enough to be the same grouping). Table-type categories
  // (Dining/Occasional/Flip-Top/Mobile/Overbed) don't appear in the
  // reference screenshot, so they're bucketed into an added "Tables" group
  // rather than left with no room category at all — flagged to the
  // customer as a judgment call, not a confirmed match to the live site.
  const ROOM_CATEGORY_MAP = {
    "Wardrobe": "Wardrobes",
    "Dresser": "Dressers",
    "Bedside Table": "Bedside Tables",
    "Bed": "Beds & Boards",
    "Bed – Headboard & Footboard": "Beds & Boards",
    "Mattress": "Beds & Boards",
    "Media Cabinet / TV Unit": "Media & Storage",
    "Dining Room Seating": "Dining Chairs",
    "Resident Room Seating": "Resident Chairs",
    "Resident Room Seating – Recliner": "Resident Chairs",
    "Resident Room Seating – Sleep Chair": "Resident Chairs",
    "Lounge Seating": "Lounge Chairs",
    "Bench Seating": "Benches",
    "Office / Meeting Seating": "Multi Purpose+Office",
    "Exam Room Seating": "Multi Purpose+Office",
    "Dining Table": "Tables",
    "Occasional Table": "Tables",
    "Flip-Top Table": "Tables",
    "Mobile / Personal Table": "Tables",
    "Overbed Table": "Tables",
  };
  const ROOM_CATEGORY_ORDER = [
    "Wardrobes", "Dressers", "Bedside Tables", "Beds & Boards", "Media & Storage",
    "Dining Chairs", "Resident Chairs", "Lounge Chairs", "Benches", "Multi Purpose+Office", "Tables",
  ];

  // Finishes, Accessories, Hardware, and Add-ons are reference/spec data —
  // they exist to answer "what finish/hardware options does THIS product
  // have", not to be browsed as if they were products in their own right.
  // The main search grid only ever shows AssetType "Product" rows; the
  // other asset types surface exclusively inside a product's View modal
  // (see openModal / finishesForItem / hardwareForItem below).
  function browsableItems() {
    return allItems.filter(i => i.AssetType === "Product");
  }

  // ProductCategory values that actually have drawers/doors and so are the
  // only ones handles/pulls (AssetType "Hardware") make sense on. Tables,
  // beds, seating, mattresses, etc. never take a cabinet handle.
  const HARDWARE_CATEGORIES = ["Wardrobe", "Dresser", "Bedside Table"];

  // ---------- DOM refs ----------
  const el = {
    filterBar: document.getElementById("filterBar"),
    searchInput: document.getElementById("searchInput"),
    clearSearch: document.getElementById("clearSearch"),
    resultsGrid: document.getElementById("resultsGrid"),
    resultsMeta: document.getElementById("resultsMeta"),
    emptyState: document.getElementById("emptyState"),
    loadingState: document.getElementById("loadingState"),

    modalOverlay: document.getElementById("modalOverlay"),
    modalClose: document.getElementById("modalClose"),
    modalImage: document.getElementById("modalImage"),
    modalChip: document.getElementById("modalChip"),
    modalProductName: document.getElementById("modalProductName"),
    modalCode: document.getElementById("modalCode"),
    modalDesc: document.getElementById("modalDesc"),
    modalPrice: document.getElementById("modalPrice"),
    modalDownloadMain: document.getElementById("modalDownloadMain"),

    gridProducts: document.getElementById("grid-products"),
    gridFinishes: document.getElementById("grid-finishes"),
    gridAccessories: document.getElementById("grid-accessories"),
    gridHardware: document.getElementById("grid-hardware"),
    gridAddons: document.getElementById("grid-addons"),

    selectionBar: document.getElementById("selectionBar"),
    selectionCount: document.getElementById("selectionCount"),
    clearSelectionBtn: document.getElementById("clearSelection"),
    downloadSelectedBtn: document.getElementById("downloadSelected"),

    lightboxOverlay: document.getElementById("lightboxOverlay"),
    lightboxImage: document.getElementById("lightboxImage"),
    lightboxClose: document.getElementById("lightboxClose"),

    toast: document.getElementById("toast"),

    cartBtn: document.getElementById("cartBtn"),
    cartBadge: document.getElementById("cartBadge"),
    cartDrawerOverlay: document.getElementById("cartDrawerOverlay"),
    cartDrawerClose: document.getElementById("cartDrawerClose"),
    cartDrawerBody: document.getElementById("cartDrawerBody"),
    cartClearBtn: document.getElementById("cartClearBtn"),
    cartDownloadZipBtn: document.getElementById("cartDownloadZipBtn"),
    cartBuildBtn: document.getElementById("cartBuildBtn"),
    modalCartAdd: document.getElementById("modalCartAdd"),

    builderOverlay: document.getElementById("builderOverlay"),
    builderClose: document.getElementById("builderClose"),
    builderItemCount: document.getElementById("builderItemCount"),
    builderCustomer: document.getElementById("builderCustomer"),
    builderTitle: document.getElementById("builderTitle"),
    builderSalesRep: document.getElementById("builderSalesRep"),
    builderGenerateBtn: document.getElementById("builderGenerateBtn"),
    builderStatus: document.getElementById("builderStatus"),
  };

  // =========================================================
  // CSV PARSING (small RFC4180-ish parser — handles quoted
  // fields containing commas, quotes, and newlines)
  // =========================================================
  function parseCSV(text) {
    const rows = [];
    let row = [];
    let field = "";
    let inQuotes = false;

    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      const next = text[i + 1];

      if (inQuotes) {
        if (c === '"' && next === '"') { field += '"'; i++; }
        else if (c === '"') { inQuotes = false; }
        else { field += c; }
      } else {
        if (c === '"') { inQuotes = true; }
        else if (c === ",") { row.push(field); field = ""; }
        else if (c === "\r") { /* skip, handled by \n */ }
        else if (c === "\n") { row.push(field); rows.push(row); row = []; field = ""; }
        else { field += c; }
      }
    }
    // last field/row (files may or may not end with newline)
    if (field.length > 0 || row.length > 0) { row.push(field); rows.push(row); }

    if (rows.length === 0) return [];
    const headers = rows[0].map(h => h.trim());
    return rows.slice(1)
      .filter(r => r.some(cell => cell && cell.trim() !== ""))
      .map(r => {
        const obj = {};
        headers.forEach((h, idx) => { obj[h] = (r[idx] || "").trim(); });
        return obj;
      });
  }

  // =========================================================
  // DATA LOADING
  // =========================================================
  async function loadProducts() {
    try {
      const res = await fetch("products.csv", { cache: "no-store" });
      if (!res.ok) throw new Error("fetch not ok");
      const text = await res.text();
      if (!text || !text.trim()) throw new Error("empty csv");
      return parseCSV(text);
    } catch (err) {
      // Expected when opened as file:// — use the embedded fallback.
      if (window.EMBEDDED_PRODUCTS_CSV) {
        return parseCSV(window.EMBEDDED_PRODUCTS_CSV);
      }
      console.error("Could not load product data:", err);
      return [];
    }
  }

  // =========================================================
  // HELPERS
  // =========================================================
  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str == null ? "" : String(str);
    return div.innerHTML;
  }

  function imgSrc(item) {
    return item.Image ? `images/${item.Image}` : "";
  }

  function filenameFor(item) {
    if (!item.Image) return "image.jpg";
    const parts = item.Image.split("/");
    return parts[parts.length - 1];
  }

  function showToast(msg, duration = 3200) {
    el.toast.textContent = msg;
    el.toast.hidden = false;
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => { el.toast.hidden = true; }, duration);
  }

  function placeholderThumb(label) {
    return `<div class="card-image-placeholder">No image<br>${escapeHTML(label || "")}</div>`;
  }

  // =========================================================
  // FILTER BAR
  // =========================================================
  function buildFilterBar() {
    const products = browsableItems();
    const seriesPresent = new Set(products.map(i => i.Category).filter(c => SERIES_ORDER.includes(c)));

    // ---- Row 1: All, Series, then Accessories/Finishes/Hardware ----
    const row1 = [{ key: "All", label: "All", count: products.length }];
    SERIES_ORDER.filter(s => seriesPresent.has(s)).forEach(s => {
      row1.push({ key: s, label: s, count: products.filter(i => i.Category === s).length });
    });
    ASSET_TABS.forEach(t => {
      const count = allItems.filter(i => i.AssetType === t.assetType).length;
      if (count > 0) row1.push({ key: t.key, label: t.label, count });
    });

    // ---- Row 2: room/type categories, own "All" ----
    const row2 = [{ key: "room:all", label: "All", count: products.length }];
    ROOM_CATEGORY_ORDER.forEach(room => {
      const count = products.filter(i => ROOM_CATEGORY_MAP[i.ProductCategory] === room).length;
      if (count > 0) row2.push({ key: `room:${room}`, label: room, count });
    });

    const renderRow = (defs) => defs.map(d => `
      <button class="filter-btn${d.key === activeCategory ? " active" : ""}" data-cat="${escapeHTML(d.key)}">
        ${escapeHTML(d.label)}<span class="count">${d.count}</span>
      </button>`).join("");

    el.filterBar.innerHTML = `
      <div class="filter-bar-row">${renderRow(row1)}</div>
      <div class="filter-bar-label">Browse by Room</div>
      <div class="filter-bar-row">${renderRow(row2)}</div>
    `;

    el.filterBar.querySelectorAll(".filter-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        activeCategory = btn.dataset.cat;
        el.filterBar.querySelectorAll(".filter-btn").forEach(b => b.classList.toggle("active", b === btn));
        applyFilters();
      });
    });
  }

  // =========================================================
  // SEARCH + FILTER
  // =========================================================
  function applyFilters() {
    const term = searchTerm.trim().toLowerCase();

    let base;
    if (activeCategory.startsWith("asset:")) {
      // Accessories/Finishes/Hardware, browsed directly as their own list
      // (separate from what a product's View panel shows for itself).
      const assetType = activeCategory.slice("asset:".length);
      base = allItems.filter(i => i.AssetType === assetType);
    } else if (activeCategory.startsWith("room:")) {
      const room = activeCategory.slice("room:".length);
      base = browsableItems().filter(i => room === "all" || ROOM_CATEGORY_MAP[i.ProductCategory] === room);
    } else if (activeCategory === "All") {
      base = browsableItems();
    } else {
      // A bare series value, e.g. "100 Series"
      base = browsableItems().filter(i => i.Category === activeCategory);
    }

    filteredItems = base.filter(item => {
      if (!term) return true;
      const haystack = `${item.ProductCode} ${item.ProductName} ${item.Description}`.toLowerCase();
      return haystack.includes(term);
    });

    renderResults();
  }

  // =========================================================
  // RESULTS GRID
  // =========================================================
  function renderResults() {
    el.loadingState.hidden = true;

    if (filteredItems.length === 0) {
      el.resultsGrid.innerHTML = "";
      el.emptyState.hidden = false;
      el.resultsMeta.textContent = "";
      return;
    }
    el.emptyState.hidden = true;
    el.resultsMeta.textContent = `${filteredItems.length} item${filteredItems.length === 1 ? "" : "s"}`;

    el.resultsGrid.innerHTML = filteredItems.map((item, idx) => {
      const src = imgSrc(item);
      const image = src
        ? `<img src="${escapeHTML(src)}" alt="${escapeHTML(item.ProductName)}" loading="lazy" data-fallback-name="${escapeHTML(item.ProductName)}">`
        : placeholderThumb(item.ProductName);

      const chip = item.AssetType === "Product"
        ? escapeHTML(item.Category || item.ProductCategory || "")
        : escapeHTML(item.Category || "");

      return `
      <article class="product-card" data-idx="${idx}">
        <div class="card-image-wrap">${image}</div>
        <div class="card-body">
          ${chip ? `<span class="card-chip">${chip}</span>` : ""}
          <p class="card-name">${escapeHTML(item.ProductName)}</p>
          ${item.ProductCode ? `<p class="card-code">${escapeHTML(item.ProductCode)}</p>` : ""}
          <p class="card-desc">${escapeHTML(item.Description)}</p>
          <div class="card-actions">
            <button class="btn btn-secondary btn-view" data-idx="${idx}">View</button>
            <button class="btn btn-tertiary btn-download" data-idx="${idx}">Download</button>
          </div>
          <button class="btn btn-cart-add" data-idx="${idx}">+ Add to Catalogue</button>
        </div>
      </article>`;
    }).join("");

    el.resultsGrid.querySelectorAll(".card-image-wrap img").forEach(img => {
      img.addEventListener("error", () => {
        const label = img.dataset.fallbackName || "";
        img.parentElement.innerHTML = placeholderThumb(label);
      }, { once: true });
    });

    el.resultsGrid.querySelectorAll(".btn-view").forEach(btn => {
      btn.addEventListener("click", () => openModal(filteredItems[Number(btn.dataset.idx)]));
    });
    el.resultsGrid.querySelectorAll(".btn-download").forEach(btn => {
      btn.addEventListener("click", () => downloadSingleImage(filteredItems[Number(btn.dataset.idx)]));
    });
    el.resultsGrid.querySelectorAll(".btn-cart-add").forEach(btn => {
      btn.addEventListener("click", () => addToCart(filteredItems[Number(btn.dataset.idx)]));
    });
  }

  // =========================================================
  // SINGLE IMAGE DOWNLOAD
  // =========================================================
  function downloadSingleImage(item) {
    const src = imgSrc(item);
    if (!src) { showToast("No image available for this item."); return; }
    const a = document.createElement("a");
    a.href = src;
    a.download = filenameFor(item);
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  // =========================================================
  // MODAL
  // =========================================================
  let currentModalItem = null;

  function openModal(item) {
    currentModalItem = item;
    const src = imgSrc(item);

    el.modalImage.src = src || "";
    el.modalImage.alt = item.ProductName;
    el.modalImage.onerror = () => { el.modalImage.style.display = "none"; };
    el.modalImage.style.display = "";

    el.modalChip.textContent = item.Category || item.ProductCategory || "";
    el.modalProductName.textContent = item.ProductName;
    el.modalCode.textContent = item.ProductCode || "";
    el.modalDesc.textContent = item.Description || "";

    if (item.Price) {
      const isPlaceholder = /confirm|request.*quote/i.test(item.Price);
      el.modalPrice.textContent = isPlaceholder ? "Price: request a quote" : item.Price;
    } else {
      el.modalPrice.textContent = "";
    }

    renderAssetSection(el.gridProducts, [item], "product");
    renderAssetSection(el.gridFinishes, finishesForItem(item), "finish");
    renderAssetSection(el.gridAccessories, allItems.filter(i => i.AssetType === "Accessory"), "accessory");
    renderAssetSection(el.gridHardware, hardwareForItem(item), "hardware");
    renderAssetSection(el.gridAddons, allItems.filter(i => i.AssetType === "Addon"), "addon");

    el.modalOverlay.hidden = false;
    document.body.style.overflow = "hidden";
  }

  function closeModal() {
    el.modalOverlay.hidden = true;
    document.body.style.overflow = "";
    currentModalItem = null;
  }

  // Finishes are now tagged per-collection (and, where needed, per-series)
  // via the AppliesTo column (see products.csv / README) instead of being
  // one big undifferentiated list shown on every product. AppliesTo holds
  // a comma-separated list of tokens, each either:
  //   - a bare Collection name, e.g. "Poise"            (matches that Collection, any series)
  //   - a "Collection:Category" pair, e.g. "Lumen:400 Series"  (matches only that exact series)
  // This lets e.g. Thermofoil finishes apply only to Lumen Contour (400
  // Series) fronts while Laminate finishes apply to the other Lumen series,
  // even though both share the same "Lumen" Collection.
  function finishesForItem(item) {
    const collection = (item.Collection || "").trim();
    const category = (item.Category || "").trim();
    return allItems.filter(i => {
      if (i.AssetType !== "Finish") return false;
      const appliesTo = (i.AppliesTo || "").trim();
      if (!appliesTo) return true; // untagged = general library, show for all
      const tokens = appliesTo.split(",").map(s => s.trim());
      return tokens.some(token => {
        if (token.includes(":")) {
          const [tokCollection, tokCategory] = token.split(":").map(s => s.trim());
          return tokCollection === collection && tokCategory === category;
        }
        return token === collection;
      });
    });
  }

  // Handles/pulls only make sense on products that actually have drawers
  // or doors — a dining table or a lounge chair never takes a cabinet
  // handle. Scoped by ProductCategory (see HARDWARE_CATEGORIES above)
  // rather than Collection, since the same collection (Lumen) contains
  // both wardrobes/dressers (take hardware) and, elsewhere, non-casegood
  // items. Hardware itself has no per-style AppliesTo data from the source
  // matrix (it's "all casegoods" uniformly), so this is a flat category
  // check rather than the token matching finishesForItem uses.
  function hardwareForItem(item) {
    if (!HARDWARE_CATEGORIES.includes(item.ProductCategory)) return [];
    return allItems.filter(i => i.AssetType === "Hardware");
  }

  function renderAssetSection(container, items, kind) {
    if (!items || items.length === 0) {
      container.innerHTML = `<p class="asset-empty">No ${kind} assets available yet.</p>`;
      return;
    }
    container.innerHTML = items.map(item => {
      const src = imgSrc(item);
      const key = src;
      const checked = selected.has(key) ? "checked" : "";
      const thumbImg = src
        ? `<img src="${escapeHTML(src)}" alt="${escapeHTML(item.ProductName)}" loading="lazy">`
        : "";
      return `
        <div class="thumb" data-src="${escapeHTML(src)}" data-name="${escapeHTML(filenameFor(item))}" data-cart-key="${escapeHTML(cartKey(item))}">
          ${src ? `<input type="checkbox" class="thumb-checkbox" ${checked}>` : ""}
          ${thumbImg}
          <button class="thumb-cart-add" title="Add to Catalogue" aria-label="Add to Catalogue">+</button>
          <span class="thumb-label">${escapeHTML(item.ProductName)}</span>
        </div>`;
    }).join("");

    container.querySelectorAll(".thumb").forEach((thumbEl, i) => {
      const src = thumbEl.dataset.src;
      const name = thumbEl.dataset.name;
      const checkbox = thumbEl.querySelector(".thumb-checkbox");
      const img = thumbEl.querySelector("img");
      const cartAddBtn = thumbEl.querySelector(".thumb-cart-add");

      if (img) {
        img.addEventListener("click", (e) => {
          e.stopPropagation();
          openLightbox(src);
        });
      }

      if (cartAddBtn) {
        cartAddBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          addToCart(items[i]);
        });
      }

      if (checkbox) {
        checkbox.addEventListener("click", (e) => e.stopPropagation());
        checkbox.addEventListener("change", () => {
          if (checkbox.checked) selected.set(src, { path: src, name });
          else selected.delete(src);
          updateSelectionBar();
        });
      }
    });
  }

  function updateSelectionBar() {
    const count = selected.size;
    el.selectionBar.hidden = count === 0;
    el.selectionCount.textContent = `${count} selected`;
  }

  // =========================================================
  // LIGHTBOX
  // =========================================================
  function openLightbox(src) {
    if (!src) return;
    el.lightboxImage.src = src;
    el.lightboxOverlay.hidden = false;
  }
  function closeLightbox() {
    el.lightboxOverlay.hidden = true;
    el.lightboxImage.src = "";
  }

  // =========================================================
  // BULK ZIP DOWNLOAD
  // =========================================================
  /**
   * Bundles the given {path, name} items into a single ZIP and downloads
   * it. Shared by both the per-product modal selection and the Catalogue
   * Cart, so there's one battle-tested download path instead of two.
   */
  async function zipAndDownload(items, btn, defaultLabel, zipFileName) {
    if (items.length === 0) return;

    if (typeof JSZip === "undefined") {
      fallbackSequentialDownload(items);
      return;
    }

    if (btn) { btn.textContent = "Zipping…"; btn.disabled = true; }

    try {
      const zip = new JSZip();
      const usedNames = new Set();

      for (const item of items) {
        const res = await fetch(item.path);
        if (!res.ok) throw new Error("fetch failed for " + item.path);
        const blob = await res.blob();
        let name = item.name;
        if (usedNames.has(name)) {
          const dot = name.lastIndexOf(".");
          name = dot > -1 ? `${name.slice(0, dot)}_${usedNames.size}${name.slice(dot)}` : `${name}_${usedNames.size}`;
        }
        usedNames.add(name);
        zip.file(name, blob);
      }

      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const a = document.createElement("a");
      a.href = url;
      a.download = zipFileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      showToast(`Downloaded ${items.length} image${items.length === 1 ? "" : "s"} as a ZIP.`);
    } catch (err) {
      console.warn("ZIP bundling failed, falling back to individual downloads:", err);
      fallbackSequentialDownload(items);
    } finally {
      if (btn) { btn.textContent = defaultLabel; btn.disabled = false; }
    }
  }

  async function downloadSelected() {
    const items = Array.from(selected.values());
    await zipAndDownload(items, el.downloadSelectedBtn, "Download Selected", "intellicare-images.zip");
  }

  async function downloadCartImages() {
    const items = Array.from(cart.values())
      .filter((item) => item.Image)
      .map((item) => ({ path: imgSrc(item), name: filenameFor(item) }));

    const skipped = cart.size - items.length;
    if (items.length === 0) {
      showToast("Nothing in your catalogue cart has an image to download yet.");
      return;
    }

    await zipAndDownload(items, el.cartDownloadZipBtn, "Download Images", "intellicare-catalogue-images.zip");

    if (skipped > 0) {
      showToast(`${skipped} cart item${skipped === 1 ? "" : "s"} had no image and ${skipped === 1 ? "was" : "were"} skipped.`, 5000);
    }
  }

  function fallbackSequentialDownload(items) {
    showToast("Your browser blocked bulk zipping of local files — downloading images individually instead.");
    items.forEach((item, i) => {
      setTimeout(() => {
        const a = document.createElement("a");
        a.href = item.path;
        a.download = item.name;
        document.body.appendChild(a);
        a.click();
        a.remove();
      }, i * 350);
    });
  }

  // =========================================================
  // CATALOGUE CART (used to build customer presentations)
  // =========================================================
  function cartKey(item) {
    return item.Image || `${item.AssetType}|${item.ProductCode || item.ProductName}`;
  }

  function addToCart(item) {
    cart.set(cartKey(item), item);
    saveCart();
    updateCartUI();
    showToast(`Added "${item.ProductName}" to the catalogue cart.`);
  }

  function removeFromCart(key) {
    cart.delete(key);
    saveCart();
    updateCartUI();
  }

  function saveCart() {
    // Intentionally a no-op — the cart is no longer persisted across
    // sessions (see loadCart below). Kept as a function so every existing
    // call site doesn't need to change; it just does nothing now.
  }

  function loadCart() {
    // Cart persistence was removed 2026-09-18: previously the cart was
    // saved to localStorage and restored on every page load, so items
    // selected in a past session would still be sitting in the cart the
    // next time someone opened the app — reported as unwanted behavior.
    // The cart is now purely in-memory (a fresh Map every page load), so
    // it's always empty at the start of a session. Also actively remove
    // any cart data left over in localStorage from before this change,
    // so it doesn't linger unused forever.
    try {
      localStorage.removeItem("iof_catalogue_cart");
    } catch (e) {
      // Storage unavailable — nothing to clean up.
    }
  }

  const CART_GROUPS = [
    { type: "Product", label: "Products" },
    { type: "Finish", label: "Finishes" },
    { type: "Accessory", label: "Accessories" },
    { type: "Hardware", label: "Hardware" },
    { type: "Addon", label: "Add-ons" },
  ];

  function updateCartUI() {
    const count = cart.size;
    el.cartBadge.hidden = count === 0;
    el.cartBadge.textContent = String(count);
    renderCartDrawer();
  }

  function renderCartDrawer() {
    const items = Array.from(cart.values());
    if (items.length === 0) {
      el.cartDrawerBody.innerHTML = `<p class="asset-empty">Your catalogue cart is empty. Browse products and click "+ Add to Catalogue".</p>`;
      return;
    }

    el.cartDrawerBody.innerHTML = CART_GROUPS.map(g => {
      const groupItems = items.filter(i => i.AssetType === g.type);
      if (groupItems.length === 0) return "";
      const rows = groupItems.map(item => {
        const key = cartKey(item);
        const src = imgSrc(item);
        return `
          <div class="cart-row">
            <div class="cart-row-thumb">${src ? `<img src="${escapeHTML(src)}" alt="" loading="lazy">` : ""}</div>
            <div class="cart-row-info">
              <p class="cart-row-name">${escapeHTML(item.ProductName)}</p>
              ${item.ProductCode ? `<p class="cart-row-code">${escapeHTML(item.ProductCode)}</p>` : ""}
            </div>
            <button class="cart-row-remove" data-key="${escapeHTML(key)}" aria-label="Remove from cart">&times;</button>
          </div>`;
      }).join("");
      return `<div class="cart-group"><h3>${escapeHTML(g.label)} <span class="count">${groupItems.length}</span></h3>${rows}</div>`;
    }).join("");

    el.cartDrawerBody.querySelectorAll(".cart-row-remove").forEach(btn => {
      btn.addEventListener("click", () => removeFromCart(btn.dataset.key));
    });
  }

  function openCartDrawer() { el.cartDrawerOverlay.hidden = false; }
  function closeCartDrawer() { el.cartDrawerOverlay.hidden = true; }

  // =========================================================
  // PRESENTATION BUILDER
  // =========================================================
  function openBuilder() {
    el.builderItemCount.textContent = String(cart.size);
    el.builderStatus.textContent = "";
    el.builderOverlay.hidden = false;
  }
  function closeBuilder() { el.builderOverlay.hidden = true; }

  /**
   * Fetches an image, returning both a base64 data URI (for embedding in the
   * .pptx) and its native pixel dimensions (needed so presentation.js can
   * crop/fit images without distorting them). Returns null on failure —
   * e.g. when the app is opened as file:// in a browser that blocks local
   * fetch(); the caller falls back to a placeholder box for that image.
   */
  async function loadImageInfo(relPath) {
    const url = `images/${relPath}`;
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("fetch not ok");
      const blob = await res.blob();
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error("read failed"));
        reader.readAsDataURL(blob);
      });
      const dims = await new Promise((resolve) => {
        let settled = false;
        const finish = (result) => { if (!settled) { settled = true; resolve(result); } };
        const img = new Image();
        img.onload = () => finish({ w: img.naturalWidth || 100, h: img.naturalHeight || 100 });
        img.onerror = () => finish({ w: 100, h: 100 });
        img.src = dataUrl;
        // Safety net: never let a single stubborn image stall the whole build.
        setTimeout(() => finish({ w: 100, h: 100 }), 4000);
      });
      return { data: dataUrl, w: dims.w, h: dims.h };
    } catch (e) {
      return null;
    }
  }

  /**
   * Renders a real, smooth linear gradient to a PNG data URI via <canvas>.
   * Used for the photo veils on the cover/divider/closing slides — a true
   * per-pixel gradient instead of the old approach of stacking several
   * flat-opacity rectangles, which produced visible hard-edged banding
   * instead of a smooth fade (see 2026-09-16 feedback).
   * @param {"horizontal"|"vertical"} direction
   * @param {Array<{offset:number, color:string, alpha:number}>} stops - offset 0-1, color as "r,g,b", alpha 0-1
   */
  function makeGradientDataUri(direction, stops, w = 800, h = 600) {
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    const grad = direction === "horizontal"
      ? ctx.createLinearGradient(0, 0, w, 0)
      : ctx.createLinearGradient(0, 0, 0, h);
    stops.forEach((s) => grad.addColorStop(s.offset, `rgba(${s.color}, ${s.alpha})`));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
    return canvas.toDataURL("image/png");
  }

  /**
   * Renders a blurred, crop-to-fill ("cover") copy of an image at a fixed
   * square-ish canvas size. Used as a backdrop layer behind an uncropped
   * ("contain"-fit) copy of the same photo, so any letterbox/pillarbox gap
   * shows a soft, out-of-focus continuation of the photo instead of a flat
   * color bar — the "fill up that side" request from 2026-09-17, balanced
   * against the earlier "don't crop the photo" request: the sharp, full,
   * uncropped image still sits on top; only the backdrop behind it is
   * cropped, and it's blurred specifically so that cropping is not
   * noticeable as its own thing.
   */
  function makeBlurredBackdropDataUri(dataUri, naturalW, naturalH, size = 700, blurPx = 24) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext("2d");
        // Cover-fit math: scale so the image fills the square, cropping
        // whichever axis overflows.
        const scale = Math.max(size / naturalW, size / naturalH);
        const dw = naturalW * scale, dh = naturalH * scale;
        const dx = (size - dw) / 2, dy = (size - dh) / 2;
        // Draw oversized + blur, so blurred edge pixels never show a hard
        // boundary at the canvas edge.
        ctx.filter = `blur(${blurPx}px)`;
        ctx.drawImage(img, dx - blurPx, dy - blurPx, dw + blurPx * 2, dh + blurPx * 2);
        // Slight darken so text laid over the backdrop (near the sharp
        // image's edges) still has some contrast to work with.
        ctx.filter = "none";
        ctx.fillStyle = "rgba(12,17,26,0.35)";
        ctx.fillRect(0, 0, size, size);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = () => resolve(null);
      img.src = dataUri;
    });
  }

  function buildGradients() {
    const navy = "12,17,26"; // matches presentation.js THEME.veil (#0C111A)
    return {
      // Dark at the left edge (where cover/divider text sits), fading
      // gradually across the panel — never fully clearing, so text stays
      // legible wherever it sits. Strengthened 2026-09-17: at the previous
      // (lighter) values, bright objects in some source photos (e.g. a
      // wall-mounted outlet panel) still showed through as a distracting
      // ghost shape instead of being fully obscured.
      leftVeil: makeGradientDataUri("horizontal", [
        { offset: 0, color: navy, alpha: 0.95 },
        { offset: 0.42, color: navy, alpha: 0.8 },
        { offset: 0.75, color: navy, alpha: 0.48 },
        { offset: 1, color: navy, alpha: 0.26 },
      ], 900, 600),
      // Transparent at top, smoothly darkening to solid navy at the
      // bottom — used to fade a photo band into the closing slide's navy
      // background, and under the cover's bottom-left "Prepared by" text.
      bottomFade: makeGradientDataUri("vertical", [
        { offset: 0, color: navy, alpha: 0 },
        { offset: 0.5, color: navy, alpha: 0.35 },
        { offset: 1, color: navy, alpha: 0.94 },
      ], 600, 600),
    };
  }

  async function generatePresentation() {
    const items = Array.from(cart.values());
    if (items.length === 0) return;

    el.builderGenerateBtn.disabled = true;
    el.builderGenerateBtn.textContent = "Generating…";
    el.builderStatus.textContent = "Loading images…";

    let imagesFailed = 0;
    const itemsWithImages = [];
    for (const item of items) {
      const copy = Object.assign({}, item);
      if (item.Image) {
        const info = await loadImageInfo(item.Image);
        if (info) {
          copy._imageData = info.data;
          copy._imageW = info.w;
          copy._imageH = info.h;
        } else {
          imagesFailed++;
        }
      }
      itemsWithImages.push(copy);
    }

    const hero = {};
    const poolFiles = ["lifestyle_hero_1.jpg", "lifestyle_hero_2.jpg", "lifestyle_hero_3.jpg", "lifestyle_hero_4.jpg", "lifestyle_hero_5.jpg", "lifestyle_hero_6.jpg", "lifestyle_hero_7.jpg", "lifestyle_hero_8.jpg"];
    const poolResults = await Promise.all(poolFiles.map(f => loadImageInfo(`lifestyle-hero/${f}`)));
    hero.pool = poolResults.filter(Boolean);
    const closingInfo = await loadImageInfo("lifestyle-hero/lifestyle_hero_9.jpg");
    if (closingInfo) hero.closing = closingInfo;

    const [logoColor, logoWhite] = await Promise.all([
      loadImageInfo("branding/logo_color.png"),
      loadImageInfo("branding/logo_white.png"),
    ]);
    const logo = { color: logoColor, white: logoWhite };
    const gradients = buildGradients();

    // Detailed (up to 3/slide, full description + price) is the only
    // layout mode now — Compact/Standard were removed from the builder.
    const options = {
      customer: el.builderCustomer.value.trim(),
      title: el.builderTitle.value.trim(),
      salesRep: el.builderSalesRep.value.trim(),
      density: "Detailed",
      includePrices: document.getElementById("incPrices").checked,
      includeFinishes: document.getElementById("incFinishes").checked,
      includeAccessories: document.getElementById("incAccessories").checked,
      includeHardware: document.getElementById("incHardware").checked,
      includeAddons: document.getElementById("incAddons").checked,
    };

    el.builderStatus.textContent = "Assembling slides…";

    try {
      const pres = IOFPresentation.buildDeck(PptxGenJS, itemsWithImages, options, hero, logo, gradients);
      const safeName = (options.customer || "Intellicare-Catalogue").replace(/[^a-z0-9\-_ ]/gi, "").trim() || "Intellicare-Catalogue";
      await pres.writeFile({ fileName: `${safeName}.pptx` });

      if (imagesFailed > 0) {
        showToast(
          `Presentation downloaded — ${imagesFailed} image(s) couldn't be loaded and show as blank placeholders. ` +
          `This usually happens when opening the app directly as a file:// page; serving it from a local server fixes it.`,
          6500
        );
      } else {
        showToast("Presentation generated and downloaded.");
      }
      // Clear the cart now that it's been used to build a presentation —
      // otherwise the same items would still be sitting there for the
      // next customer/deck, which is exactly what was reported as unwanted.
      cart.clear();
      updateCartUI();
      closeBuilder();
    } catch (err) {
      console.error("Presentation generation failed:", err);
      el.builderStatus.textContent = "Something went wrong generating the presentation. Check the browser console for details.";
    } finally {
      el.builderGenerateBtn.disabled = false;
      el.builderGenerateBtn.textContent = "Generate";
    }
  }

  // =========================================================
  // EVENT WIRING
  // =========================================================
  function wireStaticEvents() {
    el.searchInput.addEventListener("input", () => {
      searchTerm = el.searchInput.value;
      el.clearSearch.hidden = searchTerm.length === 0;
      applyFilters();
    });

    el.clearSearch.addEventListener("click", () => {
      el.searchInput.value = "";
      searchTerm = "";
      el.clearSearch.hidden = true;
      el.searchInput.focus();
      applyFilters();
    });

    el.modalClose.addEventListener("click", closeModal);
    el.modalOverlay.addEventListener("click", (e) => {
      if (e.target === el.modalOverlay) closeModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        if (!el.lightboxOverlay.hidden) closeLightbox();
        else if (!el.builderOverlay.hidden) closeBuilder();
        else if (!el.cartDrawerOverlay.hidden) closeCartDrawer();
        else if (!el.modalOverlay.hidden) closeModal();
      }
    });

    el.modalDownloadMain.addEventListener("click", () => {
      if (currentModalItem) downloadSingleImage(currentModalItem);
    });

    el.lightboxClose.addEventListener("click", closeLightbox);
    el.lightboxOverlay.addEventListener("click", (e) => {
      if (e.target === el.lightboxOverlay) closeLightbox();
    });

    el.clearSelectionBtn.addEventListener("click", () => {
      selected.clear();
      updateSelectionBar();
      // Uncheck any visible checkboxes in the open modal
      document.querySelectorAll(".thumb-checkbox").forEach(cb => { cb.checked = false; });
    });

    el.downloadSelectedBtn.addEventListener("click", downloadSelected);

    // Catalogue cart
    el.cartBtn.addEventListener("click", openCartDrawer);
    el.cartDrawerClose.addEventListener("click", closeCartDrawer);
    el.cartDrawerOverlay.addEventListener("click", (e) => {
      if (e.target === el.cartDrawerOverlay) closeCartDrawer();
    });
    el.cartClearBtn.addEventListener("click", () => {
      cart.clear();
      saveCart();
      updateCartUI();
    });
    el.cartBuildBtn.addEventListener("click", () => {
      if (cart.size === 0) { showToast("Add some items to your catalogue cart first."); return; }
      closeCartDrawer();
      openBuilder();
    });
    el.cartDownloadZipBtn.addEventListener("click", () => {
      if (cart.size === 0) { showToast("Add some items to your catalogue cart first."); return; }
      downloadCartImages();
    });
    el.modalCartAdd.addEventListener("click", () => {
      if (currentModalItem) addToCart(currentModalItem);
    });

    // Presentation builder
    el.builderClose.addEventListener("click", closeBuilder);
    el.builderOverlay.addEventListener("click", (e) => {
      if (e.target === el.builderOverlay) closeBuilder();
    });
    el.builderGenerateBtn.addEventListener("click", generatePresentation);
  }

  // =========================================================
  // INIT
  // =========================================================
  async function init() {
    wireStaticEvents();
    loadCart();
    updateCartUI();
    allItems = await loadProducts();
    buildFilterBar();
    applyFilters();
  }

  init();
})();
