# Intellicare Image Finder & Presentation Creator

An internal tool for locating Intellicare product images, finishes, and
accessories without digging through folders — and for building
customer-ready PowerPoint presentations from a selection of products in a
few clicks. Pure HTML/CSS/JavaScript — no build step, no server, no
account, and no dependency on any external service to run.

## What's in this repository

This repo contains the entire tool, ready to run as-is:

- The web app itself (search, filters, image downloads, the Catalogue
  Cart, and the presentation builder)
- The full product image library (`images/`) and the product data
  (`products.csv`)
- The two small JS libraries it depends on, already included
  (`vendor/`) — nothing to install
- `source-docs/` — the original source documents finishes are derived from
  (`intellicatre-product-finish-accessory-matrix.xlsx`,
  `intellicatre-finish-options.zip`), kept for provenance/audit so anyone
  can re-derive or double-check `products.csv`'s `Finish` rows against the
  original, plus `revello-reference-deck.zip` (the "Dorval Revello
  Presentation" deck `presentation.js`'s visual design was rebuilt to
  match — see below). None of this is read by the app itself.

**Presentation design:** `presentation.js` generates decks in the
"Revello" visual style — cream/navy/gold palette, bold uppercase-tracked
labels, hairline rules — copied slide-for-slide (cover, contents, series
dividers, item grids, closing) from a reference deck supplied
2026-09-16 (`source-docs/revello-reference-deck.zip`). Typography was
originally Cormorant Garamond (serif) + Outfit (sans), matching that
reference deck exactly — both Google Fonts. Changed 2026-09-17 to
**Segoe UI** throughout: Outfit isn't bundled with Windows/Office, so on
any machine without it installed (most corporate Windows machines),
PowerPoint silently substitutes a fallback font — what was being shown
was never guaranteed to be the intended design. Segoe UI is Microsoft's
own system typeface, installed on every Windows machine by definition,
so there's no substitution risk, and it reads as standard corporate/
Office typography rather than a stylized display font — the explicit
ask ("needs to be official... showcased to executives") this changed in
response to.

**Data source:** the 181 products, 26 handles, and 15 accessories in
`products.csv` (`AssetType` = `Product` / `Hardware` / `Accessory`) are
generated from `product_master.xlsx` (the confidential-pricing source of
truth) with images from `All_222_Product_Images.zip` — both matched 1:1
by the master's `Zip Matched Filename` column, copied into
`images/products/`. This replaced the earlier, provisional product/image
set that had been assembled by hand from the price guide. The 50 `Finish`
rows are unaffected by that swap — they're not in the master spreadsheet,
so they're still the supplementary data pulled from the 2026 Price Guide
(see "Finishes are now tagged per collection" below). Two master rows
(Serenity Drift Lounge Chair, Avail Personal Mobile Table) originally had
no `Zip Matched Filename`, but a correctly-named image existed in the zip
for each one anyway (matching their loveseat/sofa siblings' naming
pattern for the former, and the written description for the latter) —
both were confirmed visually and linked manually, so all 181 products now
have an image.

**This repository is private.** Access is limited to people on the team
who need it. If you're reading this, you were added as a collaborator —
if a colleague needs access and can't see the repo, have them ask
whoever manages it to add them as a collaborator (repo Settings →
Collaborators on GitHub).

### Getting the app running — for anyone on the team

You do not need Git, a terminal, or any technical background for this.

1. On the repo's GitHub page, click the green **Code** button → **Download ZIP**
   (or use **Open with GitHub Desktop** if you have that installed)
2. Unzip the downloaded folder
3. Double-click **index.html** — it opens in your normal web browser and just works

That's the entire process. Nothing to install, nothing to configure.
Full functionality notes (a couple of browser-specific quirks around
bulk downloads/presentation generation) are covered below in **Quick start**.

### If you're using Claude Code or Git directly

```
git clone <this repo's URL>
cd intellicare-image-finder
```
then open `index.html` as above, or serve it locally (see **Quick start**).
Note that pulling a *private* repo this way requires your own GitHub
account to have collaborator access, and Git/Claude Code to be
authenticated with it — a plain chat link to Claude.ai is not enough on
its own to grant access to private repo contents.

## Quick start

Double-click **index.html**. That's it.

For full "download all selected images as one ZIP" support, some browsers
(mainly Chrome) block bulk file reads when a page is opened directly as a
`file://` path. If that happens the app automatically falls back to
downloading the selected images one by one instead — everything still
works, just as separate files rather than a single ZIP.

To unlock the ZIP feature in every browser, serve the folder locally
instead of double-clicking it, e.g. from a terminal in this folder:

```
python3 -m http.server 8080
```

then open `http://localhost:8080` in your browser.

## File structure

```
index.html          Page structure
style.css            All styling
script.js            App logic (search, filters, modal, cart, downloads, presentation builder)
presentation.js       Groups/chunks the catalogue cart and assembles the .pptx (shared logic, no DOM dependency)
data.js              Auto-generated offline copy of products.csv (see below)
products.csv         The product data — edit this to update the catalog
vendor/jszip.min.js       Bundled ZIP library (image download feature)
vendor/pptxgen.bundle.js  Bundled PowerPoint-generation library (presentation builder)
logo.png             Placeholder logo — swap for the real company logo any time
images/
  products/          One image per catalog item
  finishes/          Finish & fabric swatch images (general library)
  accessories/       Accessory images (general library)
  hardware/          Hardware images (currently empty — see images/hardware/README.txt)
  addons/            Add-on images (currently empty — see images/addons/README.txt)
  lifestyle-hero/    Room photography used as cover/closing art in generated presentations
```

## Building a customer presentation

Click **"+ Add to Catalogue"** on any product card, or on any finish,
accessory, or hardware thumbnail inside a product's detail view, to add it
to the **Catalogue Cart** (the cart icon in the header shows a running
count). Open the cart, and you have two options: **Download Images**
zips up every image currently in the cart, or **Build Presentation** opens
a form covering:

- Customer name, presentation title, and sales representative
- Which sections to include — Prices, Finishes, Accessories, Hardware, Add-ons

**Generate** downloads a `.pptx` styled to match the existing Intellicare customer
decks (dark-teal cover/closing slides, sage-green content slides). Products
are laid out as up to three per slide (a large centered card for 1, side-by-side
for 2, three equal columns for 3), automatically continuing onto additional
slides beyond that — never one product per slide, never more than three.
Only sections that actually have cart items appear — an empty "Hardware"
section is simply skipped, and the table of contents lists only what's
really there, including which product types are in each series (e.g.
"300 Series — Wardrobes, Bedside Tables").

Finishes/accessories/hardware appear as a general library in the deck, same
as in the app — the source spreadsheet doesn't link specific swatches to
specific SKUs.

Building a presentation needs to read image bytes, so it has the same
`file://` limitation as the ZIP download feature below — if reading fails,
affected images fall back to blank placeholder boxes rather than breaking
the whole deck. The Catalogue Cart itself is saved to the browser's local
storage, so it survives a page reload on the same computer.

## The products.csv columns

| Column          | Meaning                                                                 |
|------------------|--------------------------------------------------------------------------|
| ProductCode      | SKU / product code shown on the card and searchable                     |
| ProductName      | Display name                                                            |
| Category         | Drives the filter buttons: `100 Series`…`600 Series`, `Finishes`, `Accessories`, `Hardware`, `Add-ons` |
| AssetType        | `Product`, `Finish`, `Accessory`, `Hardware`, or `Addon` — controls which modal section an item appears in |
| ProductCategory  | Furniture type shown as a secondary label (Wardrobe, Bed, Dresser, etc.) |
| Collection       | Product family/collection name (Lumen, Poise, Serenity, etc.)           |
| Description      | Shown on the card and in the product modal                              |
| Price            | Shown in the product modal and on presentation slides as-is (e.g. "$1,283" or "Request a quote") |
| Image            | Path relative to `images/`, e.g. `products/Poise_Solace_Resident_Room_Chair.jpg` |

Adding a new product: add a new row and drop the matching image file into
`images/products/`. No code changes needed — the app reads the CSV
dynamically.

## About data.js (the offline fallback)

Browsers refuse to `fetch()` local files opened via `file://`, so the app
can't read `products.csv` directly unless it's served over http(s). To
make the app work with a plain double-click, `data.js` contains a
byte-for-byte copy of `products.csv` embedded as a JavaScript string. The
app tries `products.csv` first (so it always picks up edits when run from
a local server) and only uses `data.js` as a fallback.

**If you edit products.csv, regenerate data.js so the fallback matches**
— otherwise people who just double-click index.html will keep seeing the
old data. Ask Claude to regenerate it, or run this one-liner from a
terminal in this folder (requires Python 3):

```
python3 -c "
content = open('products.csv', encoding='utf-8').read()
escaped = content.replace(chr(92), chr(92)*2).replace('\`', chr(92)+'\`').replace('\${', chr(92)+'\${')
open('data.js', 'w', encoding='utf-8').write(
    '// Auto-generated embedded copy of products.csv.\n'
    'window.EMBEDDED_PRODUCTS_CSV = \`' + escaped + '\`;\n'
)
"
```

## Notes on this catalog import

- Product images, series (100–600 Series), categories and prices were
  imported from Intellicare's product spreadsheet and image repository.
  To refresh the catalog with a newer spreadsheet/repository export, hand
  both files to Claude and ask it to rebuild `products.csv`, `data.js`,
  and the `images/` folder — the extraction reads columns by name, so it
  tolerates the spreadsheet's column order changing between exports.
- **Finishes are tagged per collection and, where needed, per series**, not
  dumped as one undifferentiated list. Each row in the `Finish` asset type has
  an `AppliesTo` column — a comma-separated list of tokens the finish is
  relevant to. A token is either a bare `Collection` name (e.g. `Serenity`,
  matches that collection regardless of series) or a `Collection:Category`
  pair (e.g. `Lumen:400 Series`, matches only that exact series — this is how
  Thermofoil finishes apply only to Lumen Contour/400 Series fronts while
  Laminate finishes apply to Lumen's other series, even though both share the
  `Lumen` collection). A finish left with a blank `AppliesTo` is treated as
  general and shows everywhere.

  **Source of truth:** `intellicatre-product-finish-accessory-matrix.xlsx`
  (sheet "Finishes & Hardware Reference" for the finish list + availability,
  sheet "LTC Products - Finish & Accessories" for which product lines use
  which finish type) and `intellicatre-finish-options.zip` for the actual
  swatch photography (`images/finishes/Laminate/`, `Thermofoil/`,
  `Powder-Coat/`). This replaced an earlier, provisional finish set that had
  been assembled by hand from the price guide (unphotographed name lists, and
  wood-look-aluminum swatches that turned out not to be an authoritative
  match for Poise/Haven) — that data has been fully removed rather than kept
  alongside the new source, per instruction to treat these two files as the
  single source of truth going forward.

  - **32 Laminate** swatches → Lumen Heritage/Cube/Studio/Resolve/Foundation
    (100/200/300/500/600 Series), Locale, Avail, Attune, and Tranquil tops,
    Fortis laminate bed accents.
  - **31 Thermofoil** swatches (same list minus Grigio, which isn't offered
    in thermofoil) → Lumen Contour (400 Series) fronts only.
  - **21 Powder-Coat** swatches → Serenity lounge and Haven dining chair
    frames, Tranquil table bases, Locale/Attune/Avail table frames, Fortis
    bed frames.
  - **13 unphotographed structural options** (6 Thermofoil door front
    styles, 4 Thermofoil top edge profiles, 3 kickplate styles) are included
    as text-only entries (no image) since the matrix defines them but no
    swatch photography exists for them.
  - **Intentionally has no finishes yet:** Poise wood-look-aluminum seating
    frames and Haven's wood-look-aluminum dining chairs — the matrix flags
    these as "TBC" (pending confirmation), so rather than guess, they're
    left with an empty Finishes section until that's confirmed. Same for
    Serenity/Haven upholstery/fabric (the matrix only says "order samples,"
    no defined swatch list) and the two Office/Caregiver chairs and Sustain
    overbed tables (also no defined list in the matrix).
  - **Known unresolved conflict (found 2026-09-16 review):** the finish
    matrix's "LTC Products" sheet describes three specific Haven chairs
    (HCHM5834, HCHM5833, HCHST205) as "Upholstery + Powder-coat frame" in
    six colors (Pearl/White/Charcoal/Olive/Navy/Mocha). But
    `product_master.xlsx` — the separate, authoritative product-catalog
    source — describes those *same three product codes* as wood-look-
    aluminum chairs in Nutmeg/Natural Maple/Graphite. These two source
    documents disagree about what these three chairs are actually made of.
    Powder-Coat finishes were previously scoped to show on all of Haven;
    that's been pulled back to showing none for Haven, rather than risk
    showing a confidently wrong option board. **This needs a human answer**
    (check with whoever maintains the finish matrix or the product master)
    before either document's version of these three chairs can be trusted
    for finish tagging.
  - When adding new finishes, set `AppliesTo` to the relevant token(s) so
    they surface only on the right products.
- Accessories and Hardware are still a **general library** inside a
  product's own View panel — the source spreadsheet doesn't link specific
  accessories/handles to specific SKUs, so every product's modal shows the
  full library rather than an item-specific subset. That's called out in
  the app UI.
- **The filter bar has two independent rows** (added 2026-09-16):
  - Row 1: `All`, the Series tabs, then `Accessories` / `Finishes` /
    `Hardware` — clicking one of these three browses that asset type
    directly as its own list in the main grid (separate from — and not a
    replacement for — the item-specific subset shown in a product's own
    View panel, which is unaffected).
  - Row 2 ("Browse by Room"): a second, independent single-select group
    that rolls the granular `ProductCategory` field up into broader
    customer-site-style buckets (Wardrobes, Dressers, Bedside Tables, Beds
    & Boards, Media & Storage, Dining Chairs, Resident Chairs, Lounge
    Chairs, Benches, Multi Purpose+Office) via the `ROOM_CATEGORY_MAP`
    constant in `script.js`. Verified against the real counts the customer
    supplied — 9 of 10 buckets matched exactly; "Beds & Boards" was 23 vs.
    their 24 (close enough to be the same grouping, not investigated
    further). A "Tables" bucket was added for ~24 items (dining/occasional/
    flip-top/mobile/overbed tables) that didn't fit any of the 10 named
    buckets — that's this app's own addition, not confirmed against the
    live site, since those items would otherwise have no room category at
    all. Selecting a Row 2 tab and a Row 1 tab are mutually exclusive
    (single global `activeCategory`, not a combinable two-axis filter).

- There is no "Add-ons" or "Hardware" folder or data yet — both filter
  buttons are present and ready, they'll just show an empty state until
  assets exist for them.
